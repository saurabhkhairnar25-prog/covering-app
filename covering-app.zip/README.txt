COVERING PRODUCTION APP - install guide (no Netlify needed)

FILES (upload all of them, keep the icons folder):
  index.html, manifest.webmanifest, sw.js, icons/

OPTION A - GitHub Pages (free, easiest)
 1. Sign in at github.com > New repository > name: covering-app > Public > Create.
 2. "uploading an existing file" > drag ALL files + icons folder > Commit.
 3. Settings > Pages > Source: "Deploy from a branch" > Branch: main / (root) > Save.
 4. After ~1 minute your link is:  https://YOURUSERNAME.github.io/covering-app/

OPTION B - Cloudflare Pages (free)
 Workers & Pages > Create > Pages > Upload assets > drag the folder > Deploy.

INSTALL ON PHONE
 Android (Chrome): open link > menu (3 dots) > "Install app" / "Add to Home screen".
 iPhone (Safari): open link > Share > "Add to Home Screen".

UPDATING LATER
 Replace index.html in the repo, and change VERSION in sw.js (v1 -> v2).

IMPORTANT
 Make sure the Google Apps Script web apps used inside index.html are deployed
 with access "Anyone", otherwise the installed app cannot reach them.
